# File-System
A "Slower File System" API implementation.  

## [Project Reference](http://pages.cs.wisc.edu/~dusseau/Classes/CS537-F07/Projects/P4/index.html)

### All functionalities mentioned Working, All corner cases handled.

### Test Guide::

1. make -f Makefile

2. make -f Makefile_rw

3. make -f Makefile_unlink

### Testing file/dir creation and listing;

* All tests should be done on the same File_System!

```
1. ./main_create <fs_name>

2. ./main_rw <fs_name>

3. ./main_unlink <fs_name>
```


