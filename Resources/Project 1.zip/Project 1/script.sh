make -f Make.libfs
make -f Make.main
sudo ./main disk.txt
